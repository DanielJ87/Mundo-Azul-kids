# Mundo Azul Kids — proyecto Android con compilación en la nube

Este proyecto contiene una aplicación Android nativa mínima (Kotlin) que muestra la demo local de Mundo Azul Kids dentro de una WebView. Incluye un flujo de GitHub Actions para compilar un APK de prueba sin instalar Android Studio en el teléfono.

## Compilar desde un celular Android (sin computadora)

1. En el navegador del celular, inicia sesión o crea una cuenta en GitHub.
2. Crea un repositorio nuevo llamado `MundoAzulKids`.
3. Descomprime este ZIP con el administrador de archivos del teléfono.
4. En GitHub, entra al repositorio y usa **Add file > Upload files**. Sube el contenido de la carpeta `MundoAzulKids_Android` (incluida la carpeta oculta `.github`; si el navegador no permite subir carpetas, será necesario crear esos archivos desde GitHub o usar la vista de escritorio).
5. Confirma los cambios en la rama `main`.
6. Abre la pestaña **Actions** del repositorio. El flujo **Compilar APK de Mundo Azul Kids** se ejecutará automáticamente. También puedes elegir **Run workflow**.
7. Cuando termine correctamente, abre la ejecución y descarga el artefacto `MundoAzulKids-debug-apk`. Dentro estará `app-debug.apk`.
8. Descarga el APK al teléfono y, si Android lo solicita, permite instalar desde el navegador/administrador de archivos que utilizaste. Instala solo el APK generado por tu propio repositorio.

## Qué incluye y qué no

- Incluye la demo HTML local empaquetada en la aplicación Android.
- Incluye un flujo automatizado para generar un APK **debug** de prueba.
- No incluye todavía un backend, cuentas reales, base de datos, pagos, streaming de video remoto ni panel de propietario conectado.
- El APK debug no es el paquete final firmado para publicar en Google Play. Para publicar habrá que preparar firma de lanzamiento, política de privacidad, formularios de seguridad/datos y revisar los requisitos vigentes de Google Play para aplicaciones dirigidas a niños.

## Seguridad y propiedad

No guardes contraseñas, claves privadas ni datos de familias dentro del código de la app o del repositorio. El panel exclusivo del propietario debe implementarse con autenticación segura en un servidor y permisos administrados del lado del servidor. No se ha creado todavía ninguna cuenta de administrador ni contraseña.

## Datos del proyecto

- Nombre visible: Mundo Azul Kids
- Paquete Android provisional: `com.mundoazulkids.app`
- SDK mínimo: Android 6.0 (API 23)
- SDK objetivo: API 35
- Versión inicial: 0.1.0

Antes de la primera publicación conviene confirmar el identificador de paquete, ya que cambiarlo después crea una aplicación distinta en Play Store.
